from turtle import * 

speed(-1)
n = 3

for i in range (n):
    forward (100) 
    left (360/n)
    
mainloop ()