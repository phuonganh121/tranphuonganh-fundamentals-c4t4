from turtle import *
speed(-1)
color("green")
for i in range (6):
    circle(100)
    left (60)
mainloop()
