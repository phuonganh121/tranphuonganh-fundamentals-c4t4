celsius = input ("Enter the temperature in Celsius? ")
print (int(celsius),'(C) = ', int(celsius)*1.8+32 ,"(F)")