radius = input ("Radius? ")
print ('Area =', int (radius)**2*3.14)