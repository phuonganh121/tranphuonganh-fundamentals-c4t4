from turtle import *
speed(-1)
color("green")
circle(100)
mainloop()
